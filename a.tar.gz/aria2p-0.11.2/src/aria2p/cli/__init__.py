"""The CLI submodule."""
